/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utilidades;

/**
 *
 * @author carlo
 */
public class ColoresCarro {
    public String [][] arreglocolores = {
        {"Rojo", "Negro", "Gris"},
        {"Color1", "Color2", "Color3"},
        {"negro3", "rojo3", "blanco3"},
        {"Gris", "Rojo", "Blanco"}
    };
    
}
